package com.seneritaeats.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Product(val name:String,val unit:String,val price:Int)

class MainActivity: AppCompatActivity() {
    private val products = listOf(
        Product("Chicken Momos","1kg • 40 pcs",230),
        Product("Chicken Momos","1kg • 50 pcs",230),
        Product("Veg Momos","1kg • 40 pcs",190),
        Product("Veg Momos","1kg • 50 pcs",190),
        Product("Paneer Momos","1kg • 40 pcs",230),
        Product("Paneer Momos","1kg • 50 pcs",230),
        Product("Chicken Cheese Momos","1kg • 40 pcs",275),
        Product("Chicken Cheese Momos","1kg • 50 pcs",275),
        Product("Veg Cheese Momos","1kg • 40 pcs",200),
        Product("Spring Chicken Roll","1kg",240),
        Product("Spring Veg Roll","1kg",200),
        Product("Red Chutney","500 gram",100)
    )
    private val cart = mutableListOf<Int>()

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        val box=findViewById<LinearLayout>(R.id.menuBox)
        products.forEachIndexed { i,p ->
            val row=LinearLayout(this); row.orientation=LinearLayout.HORIZONTAL
            row.setPadding(0,8,0,8)
            val t=TextView(this); t.text="• ${p.name}\n  ${p.unit}  ₹${p.price}/kg"; t.textSize=16f
            val add=Button(this); add.text="ADD"
            add.setOnClickListener { cart.add(i); updateCart() }
            row.addView(t,LinearLayout.LayoutParams(0,-2,1f)); row.addView(add)
            box.addView(row)
        }
        findViewById<Button>(R.id.cartButton).setOnClickListener { checkout() }
        findViewById<Button>(R.id.loginButton).setOnClickListener { login() }
        findViewById<Button>(R.id.whatsappButton).setOnClickListener { whatsapp() }
        findViewById<Button>(R.id.callButton).setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:8724065206"))) }
        findViewById<Button>(R.id.instagramButton).setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.instagram.com/seneritaeats/"))) }
    }
    private fun updateCart(){ findViewById<TextView>(R.id.cartText).text="🛒 Cart: ${cart.size} items" }
    private fun login(){
        val input=EditText(this); input.hint="Your name / phone"
        AlertDialog.Builder(this).setTitle("Senerita Eats Login").setMessage("Enter your name or mobile number").setView(input)
            .setPositiveButton("Continue"){_,_-> Toast.makeText(this,"Profile saved on this phone.",Toast.LENGTH_SHORT).show()}
            .setNegativeButton("Cancel",null).show()
    }
    private fun checkout(){
        if(cart.isEmpty()){ Toast.makeText(this,"पहले menu से items ADD करें.",Toast.LENGTH_SHORT).show(); return }
        val names=cart.map{products[it].name}.groupingBy{it}.eachCount().entries.joinToString("\n"){ "${it.key} × ${it.value}" }
        AlertDialog.Builder(this).setTitle("Your Order").setMessage(names+"\n\nOrder WhatsApp पर भेजें?")
            .setPositiveButton("WhatsApp"){_,_-> whatsapp()}.setNegativeButton("Cancel",null).show()
    }
    private fun whatsapp(){
        val text=if(cart.isEmpty()) "Hello Senerita Eats, मुझे wholesale momo price/menu चाहिए."
        else "Hello Senerita Eats, मेरा wholesale order:\n"+cart.map{products[it].name}.groupingBy{it}.eachCount().entries.joinToString("\n"){ "${it.key} × ${it.value}" }
        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/918724065206?text="+Uri.encode(text))))
    }
}
