SENERITA EATS FINAL v1.0.0

Mobile build:
1. Open AndroidIDE.
2. Import this ZIP.
3. Wait for Gradle sync.
4. Build -> Assemble Debug.
5. Install app-debug.apk.

This version includes home, wholesale menu, cart, checkout-to-WhatsApp, profile/login placeholder, call and Instagram.
For Play Store release, create a Play Console account, complete Google verification, and upload a signed AAB.
