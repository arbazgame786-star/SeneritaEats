Senerita Eats Android App
==========================

This is a first AndroidIDE-friendly native Android version of the Senerita Eats business page.

Included:
- Senerita Eats branding
- Wholesale menu poster
- Bulk order / WhatsApp button
- Call button
- Instagram button
- Login button placeholder (login screen can be added next)

Build on phone:
1. Open AndroidIDE.
2. Import/open this ZIP as a project.
3. Let Gradle sync/download dependencies.
4. Tap Build > Assemble Debug (or the APK build option).
5. Install the generated app-debug.apk.

Package: com.seneritaeats.app
Version: 1.0
