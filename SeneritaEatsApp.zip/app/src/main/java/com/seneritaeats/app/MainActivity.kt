package com.seneritaeats.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.loginButton).setOnClickListener {
            Toast.makeText(this, "Login screen next version में जोड़ सकते हैं.", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.menuButton).setOnClickListener {
            Toast.makeText(this, "Wholesale Menu ऊपर दिख रहा है.", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.orderButton).setOnClickListener {
            openWhatsApp()
        }

        findViewById<Button>(R.id.whatsappButton).setOnClickListener {
            openWhatsApp()
        }

        findViewById<Button>(R.id.callButton).setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:8724065206")))
        }

        findViewById<Button>(R.id.instagramButton).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/seneritaeats/")))
        }
    }

    private fun openWhatsApp() {
        val url = "https://wa.me/918724065206?text=" +
                Uri.encode("Hello Senerita Eats, मुझे wholesale momo order करना है.")
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
